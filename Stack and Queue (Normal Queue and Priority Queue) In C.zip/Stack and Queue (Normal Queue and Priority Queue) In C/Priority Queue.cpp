#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

struct Data{
	char name[100];
	int value;
	struct Data *next, *prev;
}*head = NULL, *tail = NULL;

struct Data *create_new_node(char name[], int value){
	struct Data *newNode = (struct Data *)malloc(sizeof(struct Data));
	strcpy(newNode->name, name);
	newNode->value = value;
	
	newNode->next = newNode->prev = NULL;
	return newNode;
}

bool is_empty(){
	if(head == NULL){
		return true;
	}
	return false;
}

void push_head(char name[], int value){
	struct Data *newNode = create_new_node(name, value);
	if(is_empty()){
		head = tail = newNode;
	}
	else{
		newNode->next = head;
		head->prev = newNode;
		head = newNode;
	}
}

void push_tail(char name[], int value){
	struct Data *newNode = create_new_node(name, value);
	if(is_empty()){
		head = tail = newNode;
	}
	else{
		tail->next = newNode;
		newNode->prev = tail;
		tail = newNode;
	}
}

void enqueue(char name[], int value){
	struct Data *newNode = create_new_node(name, value);
	if(is_empty()){
		head = tail = newNode;
	}
	else{
		if(value < head->value){
			push_head(name, value);
		}
		else if(value >= tail->value){
			push_tail(name, value);
		}
		else{
			struct Data *temp = tail;
			while(temp->value > value){
				temp = temp->prev;
			}
			newNode->prev = temp;
			newNode->next = temp->next;
			newNode->next->prev = newNode;
			temp->next = newNode;
		}
	}
}

void dequeue(){
	if(!is_empty()){
		struct Data *temp = head;
		head =  head->next;
		temp->next = head->prev = NULL;
		free(temp);
	}
}

void peek(){
	if(!is_empty()){
		printf("Peek(First Data): %s %d", head->name, head->value);
	}
}

void view_all_data(){
	struct Data *temp = head;
	if(!is_empty()){
		printf("Our Queue  :  \n");
		while(temp != NULL){
			printf("%s - %d \n", temp->name, temp->value);
			temp = temp->next;
		}
	}
}

int main(){
	
	enqueue("Niclauss", 3);
	enqueue("Salim", 2);
	enqueue("Handy", 4);
	enqueue("Richie", 1);
	
	view_all_data();
	peek();
	
	dequeue();
	view_all_data();
	
	return 0;
}
