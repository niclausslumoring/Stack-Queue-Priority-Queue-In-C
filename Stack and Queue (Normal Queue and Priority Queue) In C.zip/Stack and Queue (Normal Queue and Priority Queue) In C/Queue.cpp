#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>

struct node{
	int value;
	struct node *next, *prev;
};

struct node *curr, *head, *tail;

struct node* new_node(int value){
	curr = (struct node*) malloc(sizeof(struct node));
	curr->value = value;
	curr->next = curr->prev = NULL;
	
	return curr;
}

void enqueue(int value){
	curr = new_node(value);
	if(head == NULL){
		head = tail = curr;
	}
	else {
		tail->next = curr;
		curr->prev = tail;
		tail = curr;
	}
}

void dequeue(){
	if(head == NULL){
		return;
	}
	if (head == tail){
		free(head);
		head = tail = NULL;
	}
	else{
		curr = head;
		head = head->next;
		free(curr);
		head->prev = NULL;
	}
}

struct node* peek(){
	if(head == NULL){
		printf("There is no data... \n");
	}
	else{
		printf("Head's value : %d\n", head->value);
	}
	printf("\n");
	return head;
}

bool is_empty(){
	if(head == NULL){
		printf("Queue is empty... \n");
		return true;
	}
	printf("Queue is not empty... \n");
	return false;
}

void view_data(){
	curr = head;
	if(head == NULL){
		printf("There is no data... \n");
	}
	while(curr){
		printf("Value : %d \n", curr->value);
		curr = curr->next;
	}
	printf("\n");
}

int main (){
//	printf("When there is no data\n");
//	printf("============\n");
//	view_data();
//	peek();
//	is_empty();
	
	
	printf("Enqueue\n");
	printf("============\n");
	enqueue(20);
	enqueue(8);
	enqueue(19);
//	view_data();
//	peek();
//	is_empty();
	
	printf("Dequeue\n");
	printf("============\n");
	dequeue();
	dequeue();
	view_data();
	peek();
	
	return 0;
}
