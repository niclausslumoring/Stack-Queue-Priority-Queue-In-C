#include<stdio.h>
#define MAX 5

int top;

void push(int stack[], int item){
	if(top == (MAX-1)){
		printf("Stuck Full\n");
	}
	else{
		top++;
		stack[top] = item;
	}
}

int pop(int stack[]){
	int ret;
	if(top == -1){
		ret = 0;
	}
	else{
		ret = stack[top];
		top--;
	}
	return ret;
}

void display(int stack[]){
	int i;
	printf("Isi Stack: \n");
	if(top == -1){
		printf("Stack masih kosong\n");
	}
	else{
		for(i=top; i>=0; i--){
			printf("%d\n", stack[i]);
		}
	}
	printf("\n");
}

int main(){
	int stack[MAX], item;
	int pilihan;
	
	top = -1;
	do{
		do{
			printf("Menu: \n");
			printf("1. Push\n");
			printf("2. Pop\n");
			printf("3. Exit\n");
			
			printf("Pilih menu: ");
			scanf("%d", &pilihan);
			
			if(pilihan < 1 || pilihan>3){
				printf("Pilihan salah, silahkan pilih lagi\n");
			}		
		}while(pilihan < 1 || pilihan > 3);
		switch(pilihan){
				case 1:
					printf("Masukan Element untuk di push: ");
					scanf("%d", &item);
					push(stack, item);
					display(stack);
					break;
				
				case 2:
					item = pop(stack);
					if(item = 0){
						printf("Stack masih kosong\n");
					}
					else{
						display(stack);
					}
					break;
				default :
					printf("Exit\n");
			}
	}while(pilihan !=3);
	
	return 0;
}
